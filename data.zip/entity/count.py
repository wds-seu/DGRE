from distutils.ccompiler import gen_lib_options
import json

with open('./PMC1995609_entity.json') as file:
    content = json.load(file)
    clist = content['entities']
    genelist = []
    for c in clist:
        if c['type'] == 'Gene':
            genelist.append(c['text'])
    print(genelist)